<?= $this->extend('layouts/default') ?>
<?= $this->section('content') ?>
<h1><?= $title ?></h1>
<?= $this->endSection() ?>


<?= $this->section('js') ?>

<?= $this->endSection() ?>
