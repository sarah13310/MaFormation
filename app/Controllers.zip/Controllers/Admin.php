<?php

namespace App\Controllers;

class Admin extends BaseController
{    
    public function index()
    {
        $data=["title"=>"Accueil"      
        ];
        return view('Admin/index.php', $data);
    }
}
